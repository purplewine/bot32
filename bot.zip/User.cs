﻿namespace Bot_Application1
{
    internal class User
    {
        public string name { get; set; }
        public string gender { get; set; }
        public string id { get; set; }
        public string email { get; set; }
       

    }
}