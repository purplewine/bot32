﻿using Microsoft.Bot.Builder.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using Microsoft.Bot.Connector;
using Bot_Application1.Controllers;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Data.SqlClient;

namespace Bot_Application1
{
    [Serializable]
    public  class SimpleDialog : IDialog
    {
        public async Task StartAsync(IDialogContext context)
        {
           context.Wait(Dialog1);
        }
      //  string userid, name, gender, email;
      //  SqlConnection con = new SqlConnection(@"Server=tcp:crazybitto.database.windows.net,1433;Initial Catalog=Crazybitto;Persist Security Info=False;User ID=crazybitto;Password=CrzBto@123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");



        private async Task Dialog1(IDialogContext context, IAwaitable<object> result)
        {
            
          
            var activity = await result as Activity;
            //string channeldata = activity.ChannelData.ToString();
            //JObject obj = JObject.Parse(channeldata);
            // userid = obj["sender"]["id"].ToString();
            //WebClient wc = new WebClient();
            //var uservalues = wc.DownloadString("https://graph.facebook.com/v2.6/" + userid + "?fields=first_name,last_name,gender&access_token=EAAXv7RDjoToBADH0b6ZCb6weu79HQtLNzzaLnKZBVV1Y9bUONpA2LDITLJpcuZCpOHb4ZBU3BFqzyjCPzpb14QVMknFi8bEtZAL7450omZCgZAHoVhR5aiq0GYBcyvtJx3RmlnZBZAFFYZAhMZCV7psW4XRxpZC077suSs04pZBKahZAFAPAZDZD");
            //JObject userdetails = JObject.Parse(uservalues);
            // name = userdetails["first_name"].ToString() + userdetails["last_name"].ToString();
            // gender = userdetails["gender"].ToString();

            




  




            if (activity.Text.Contains("Hi"))
            {
                
                await context.PostAsync("Hi ");
                await context.PostAsync("I'am PreCaty, consult me before buying anything online. I'll help you get the latest offers and even Coupons");
                await context.PostAsync("Say about the product you wanna buy");
                context.Wait(Dialog1);


            }
            else if(activity.Text.Contains("search"))
            {
                if (activity.Text.StartsWith("search"))
                {
                    string product = activity.Text.Substring(7);
                    List<Product> lis = Flipkart.getFlipkartData(product);
                    if (lis.Count < 1)
                    {
                        await context.PostAsync("There are no offers for this product sir.Or maybe you have spelled this product wrong");
                    }
                    else
                    {
                        await context.PostAsync("There are "+lis.Count+ " products");
                        await context.PostAsync("Please visit the link below to check the deals");
                        await context.PostAsync("https://www.flipkart.com/search?q=" + product);
                    }


                }
                context.Wait(Dialog1);
            }
            else
            {
                string product = activity.Text.ToString();
                try
                {
                    List<Product> lis = Flipkart.getFlipkartData(product);
                    if (lis.Count < 1)
                    {
                        await context.PostAsync("There are no offers for this product sir.Or maybe you have spelled this product wrong");
                        context.Wait(Dialog1);
                    }
                    else
                    {
                        await context.PostAsync("There are " + lis.Count + " products");
                        await context.PostAsync("Please visit the link below to check the deals");
                        await context.PostAsync("https://www.flipkart.com/search?q=" + product);

                    }
                }
                catch
                {
                    await context.PostAsync("There are problems");

                }
                context.Wait(Dialog1);
            }
           
        }

        
            

        }

      
    }
