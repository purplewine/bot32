﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace Bot_Application1.Controllers
{
    public class Product
    {
        public string category { get; set; }
        public string description { get; set; }
        public string id { get; set; }
        public string imgurl_default { get; set; }
        public string price { get; set; }
        public string title { get; set; }
        public string url { get; set; }
        public string website { get; set; }


    }
    public class Offers
    {
        public static List<Product> GetOffer()
        {
            WebClient wc = new WebClient();
            String offerdata = wc.DownloadString("http://crazybetto.azurewebsites.net/api/Offers");
            List<Product> lis = JsonConvert.DeserializeObject<List<Product>>(offerdata.ToString());

            return lis;

        }
        public static List<Product> GetOffer(string product)
        {
            WebClient wc = new WebClient();
            String offerdata = wc.DownloadString("http://crazybetto.azurewebsites.net/api/Offers");
            List<Product> lis = JsonConvert.DeserializeObject<List<Product>>(offerdata.ToString());
            List<Product> listproduct = new List<Product>();

            foreach (var item in lis)
            {
                if (item.title.Contains(product))
                {
                    listproduct.Add(item);
                }
            }

            return listproduct;

        }

      

    }
}