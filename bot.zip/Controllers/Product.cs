﻿namespace Bot_Application1.Controllers
{
    public class Product
    {
        public string category { get; set; }
        public string description { get; set; }
        public string id { get; set; }
        public string imgurl_default { get; set; }
        public string price { get; set; }
        public string title { get; set; }
        public string url { get; set; }
        public string website { get; set; }


    }
}